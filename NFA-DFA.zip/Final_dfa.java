package final_dfa;
//Mahabub Akram
//CSC 273
//0910024040
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.StringTokenizer;
import javax.swing.*;
/**
 author: hollowtempter
 */
public class Final_dfa {

    public static int a = 97, b = 99, c = 98, first = 0, last = 11;
    public static LinkedHashMap<String, String> nfa = new LinkedHashMap<String, String>();
    public static LinkedHashMap<String, String> eget = new LinkedHashMap<String, String>();
    public static LinkedList<Integer> num = new LinkedList<Integer>();
    public static LinkedList<String> val = new LinkedList<String>();
    public static LinkedList<String> rad = new LinkedList<String>();
    public static LinkedHashMap<String, String> dfa = new LinkedHashMap<String, String>();
    public static LinkedHashMap<String, String> rat = new LinkedHashMap<String, String>();
    public static LinkedHashMap<String, String> symbol = new LinkedHashMap<String, String>();
    public static LinkedHashMap<String, String> dfa_s = new LinkedHashMap<String, String>();
    public static LinkedList<String> resultant = new LinkedList<String>();
    public static LinkedList<String> in_symbol = new LinkedList<String>();
    public static LinkedList<String> states = new LinkedList<String>();
    public static LinkedHashMap<String, String> min_states = new LinkedHashMap<String, String>();
    public static LinkedHashMap<String, String> merged_states = new LinkedHashMap<String, String>();
    public static LinkedHashMap<String, String> new_states = new LinkedHashMap<String, String>();
    public static LinkedList<Integer> result = new LinkedList<Integer>();
    public static LinkedHashMap<String, String> min_dfa = new LinkedHashMap<String, String>();
    public static LinkedList<String>min_resultant=new LinkedList<String>();
    // public static int c = 50, i = 0;
    public static int sym = 65;
    public static boolean decision = false;
    public static String follow = "";
    public static int edges = 2;

    public static void eclosebuilder() {
        for (int k = first; k < last; k++) {
            String build = "" + k;
            upper(build);
            String s = "";
            //System.out.println(num);
            //Collections.sort(num);
            for (int j = 0; j < num.size(); j++) {
                s = s + "_" + num.get(j);
            }
            //System.out.println(s);
            num.clear();
            eget.put(build, s);
        }
        //System.out.println(eget+"egetter");
        return;
    }

    public static void upper(String cip) {
        //System.out.println("this is cip " + cip + "Here comes the new upper" + num);
        if (!nfa.get(cip + "_e").equals("")) {
            if (!num.contains(Integer.parseInt(cip))) {
                num.add(Integer.parseInt(cip));
                // System.out.println(num.contains(cip)+" so this is num "+num.size());
                Collections.sort(num);
                String put = nfa.get(cip + "_e");
                LinkedList<String> check = new LinkedList<String>();
                StringTokenizer st = new StringTokenizer(put);
                while (st.hasMoreElements()) {
                    check.add(st.nextToken("_"));
                }
                //System.out.println(check);
                while (check.size() != 0) {
                    String s = check.getFirst();
                    check.removeFirst();
                    // System.out.println(s);
                    upper(s);
                }
            }
        }

        if (nfa.get(cip + "_e").equals("")) {
            if (!num.contains(Integer.parseInt(cip))) {
                num.add(Integer.parseInt(cip));
                Collections.sort(num);
            }
        }


    }

    public static void ecloser(String s) {
        for (int j = (int) in_symbol.getFirst().charAt(0); j <= (int) in_symbol.getLast().charAt(0); j++) {
            String trans = eget.get(s);
            String pulp = "";
            // System.out.println(trans);
            StringTokenizer st = new StringTokenizer(trans);
            while (st.hasMoreElements()) {
                String risk = nfa.get(st.nextToken("_") + "_" + (char) j);
                if (risk.equals("")) {
                    continue;
                }
                pulp = pulp + eget.get(risk);
            }
            if (val.contains(pulp) == false && !pulp.equals("")) {
                //System.out.println("this is false");
                val.add(pulp);
                rad.add(pulp);
                symbol.put(pulp, (char) sym + "");
                states.add((char) sym + "");
                sym++;
                final_states(pulp);
                //System.out.println("this is rad : "+rad);
            }

            dfa.put(eget.get(s) + "_" + (char) j, pulp);
            dfa_s.put(symbol.get(eget.get(s)) + "_" + (char) j, symbol.get(pulp));
            //System.out.println("We are getting ecloser "+s +"and dfa is "+dfa);
            //System.out.println(dfa);
        }

    }

    public static void efusser(String s) {
        for (int j = (int) in_symbol.getFirst().charAt(0); j <= (int) in_symbol.getLast().charAt(0); j++) {
            // System.out.println("this is rat : "+rat);
            String pulp = "";
            // System.out.println(trans);
            String risk = nfa.get(s + "_" + (char) j);
            if (risk.equals("")) {
                continue;
            }
            if (rat.get((char) j + "_") != null) {
                risk = risk + "_" + rat.get((char) j + "_");
                //  System.out.println("astalavista "+(char)j+rat.get((char)j+"_"));
            }
            rat.put((char) j + "_", risk);
        }
        //System.out.println(rat);

    }

    public static void dfbuilder(String pat, String mat, int j) {
        //  System.out.println("this is mat and pat "+mat +" " +pat +" "+pat.length());
        if (mat != null) {
            String pulp = "";
            String s = "";
            StringTokenizer rt = new StringTokenizer(mat);
            while (rt.hasMoreElements()) {
                s = rt.nextToken("_");
                String trans = eget.get(s);
                pulp = trans + pulp;
            }
            //System.out.println(pat+"  "+"   "+pulp);
            if (val.contains(pulp) == false && !"".equals(pulp)) {
                val.add(pulp);
                rad.add(pulp);
                symbol.put(pulp, (char) sym + "");
                states.add((char) sym + "");
                sym++;
                final_states(pulp);
            }
            dfa.put(pat + "_" + (char) j, pulp);
            dfa_s.put(symbol.get(pat) + "_" + (char) j, symbol.get(pulp));
            // System.out.println(dfa);
            //System.out.println(dfa);
        }
        if (!"".equals(pat) && mat == null) {
            //System.out.println(pat.length());
            dfa.put(pat + "_" + (char) j, "");
            dfa_s.put(symbol.get(pat) + "_" + (char) j, null);
            //System.out.println(dfa);
        }


        //String rr=dfa.get("1_b");
        //System.out.println(rr.length());
    }

    public static void final_states(String pitch) {
        String s = pitch;
        StringTokenizer rip = new StringTokenizer(s);
        while (rip.hasMoreElements()) {
            String state = rip.nextToken("_");
            if (result.contains(Integer.parseInt(state))) {
                resultant.push(symbol.get(pitch));
                break;
            }
        }
        return;
    }

    public static void generate() {
        LinkedList<String> gen = new LinkedList<String>();
        for (int i = 0; i < in_symbol.size(); i++) {
            gen.add(in_symbol.get(i));
        }

        while (!gen.isEmpty()) {
            String rape = gen.getFirst();
            gen.removeFirst();

            if (rape.length() > 5) {
                continue;
            }
            in_symbol.add(rape);
            //System.out.println(rape);

            for (int i = 0; i < in_symbol.size(); i++) {
                String temp = rape + in_symbol.get(i);
                gen.add(temp);
            }
        }
    }

    public static String laster(String inputter, String stater) {

        for (int i = 0; i < inputter.length(); i++) {
            if (i == 0) {
                // System.out.print(stater + "-->");
                follow = dfa_s.get(stater + "_" + inputter.charAt(i));
            } else {
                // System.out.print(dfa_s.get(follow + "_" + inputter.charAt(i)) + "-->");
                follow = dfa_s.get(follow + "_" + inputter.charAt(i));
            }
        }
        // System.out.println("this is state"+stater+"  "+follow +"this is input "+inputter);
        return follow;
    }

    public static boolean checker(String input, String state_1, String state_2) {
        if (resultant.contains(laster(input, state_1)) == true && resultant.contains(laster(input, state_2)) == false) {
            return false;
        }
        if (resultant.contains(laster(input, state_1)) == false && resultant.contains(laster(input, state_2)) == true) {
            return false;
        }

        if (laster(input, state_1).equals(laster(input, state_2))) {
            return true;
        } else {
            return false;
        }
    }

    public static void main(String[] args) throws IOException {
        int medium = 0;
        medium = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter 1, 2 or 3 \n 1.To give console input \n 2. To Use default defined input for checking \n 3.To exit"));

        switch (medium) {

            case 1: {
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

                System.out.print("Number of states: ");
                last = Integer.parseInt(br.readLine());
                System.out.println();

                System.out.print("Start State: ");
                first = Integer.parseInt(br.readLine());
                System.out.println();

                System.out.println("Number of final state: ");
                int f_loop = Integer.parseInt(br.readLine());
                for (int i = 0; i < f_loop; i++) {
                    System.out.print(i + 1 + ". ");
                    result.add(Integer.parseInt(br.readLine()));
                }
                System.out.println("Number of input symbols");
                int s_loop = Integer.parseInt(br.readLine());
                edges = s_loop;
                for (int i = 0; i < s_loop; i++) {
                    System.out.print(i + 1 + ". ");
                    in_symbol.add(br.readLine());
                }

                for (int k = first; k < last; k++) {
                    System.out.print("Number of states for epsilon moves from : " + k + " is :");
                    int e_loop = Integer.parseInt(br.readLine());
                    System.out.println();
                    String e_move = "";
                    if (e_loop == 1) {
                        System.out.print(e_loop + ". ");
                        e_move = br.readLine();
                    }
                    if (e_loop > 1) {
                        for (int i = 0; i < e_loop; i++) {
                            System.out.print(i + 1 + ". ");
                            if (i == e_loop - 1) {
                                e_move += br.readLine();
                            } else {
                                e_move += br.readLine();
                                e_move += "_";
                            }

                        }

                    }
                    nfa.put(k + "_" + "e", e_move);

                    for (int i = 0; i < in_symbol.size(); i++) {
                        System.out.println();
                        System.out.print("Number of states for " + in_symbol.get(i) + " moves from : " + k + " is :");
                        int in_loop = Integer.parseInt(br.readLine());
                        System.out.println();
                        String in_move = "";
                        if (in_loop == 1) {
                            System.out.print(in_loop + ". ");
                            in_move = br.readLine();
                            System.out.println();
                        }

                        if (in_loop > 1) {
                            for (int j = 0; j < in_loop; j++) {
                                System.out.print(j + 1 + ". ");
                                if (j == in_loop - 1) {
                                    in_move += br.readLine();
                                } else {
                                    in_move += br.readLine();
                                    in_move += "_";
                                }

                                System.out.println();
                            }

                        }
                        nfa.put(k + "_" + in_symbol.get(i), in_move);
                    }

                }
                System.out.println(in_symbol);
                System.out.println(first);
                System.out.println(last);
                System.out.print(nfa);
                eclosebuilder();
                symbol.put(eget.get(first + ""), (char) sym + "");
                states.add((char) sym + "");
                sym++;
                final_states(eget.get(first + ""));
                System.out.println("this is first input " + symbol);
                ecloser(first + "");
                //System.out.println(eget);z

                while (!rad.isEmpty()) {
                    rat.clear();
                    String set = rad.getFirst();
                    //System.out.println("this is set "+set);
                    rad.removeFirst();
                    StringTokenizer st = new StringTokenizer(set);
                    while (st.hasMoreElements()) {
                        String risk = st.nextToken("_");
                        efusser(risk);
                    }
                    for (int r = a; r <= c; r++) {
                        dfbuilder(set, rat.get((char) r + "_"), r);
                    }
                }

                System.out.println(" Final dfa ");
                System.out.println(dfa);
                JOptionPane.showMessageDialog(null, "This is my dfa HashMap small letters are edges"
                        + "\n & numbers  are states "+"\n"+dfa);
                System.out.println("Value considering as symbols");
                System.out.println(symbol);
                JOptionPane.showMessageDialog(null, "the value which are accepting as Symbols \n"+symbol);
                System.out.println("Final symbolic dfa");
                System.out.println(dfa_s);
                JOptionPane.showMessageDialog(null, "This is my main dfa HashMap small letters are"
                        + " edges & Block letters are State \n"+dfa_s);
                System.out.println("Final States are :");
                System.out.println(resultant);
                JOptionPane.showMessageDialog(null, "Final States are \n"+resultant);

                JOptionPane.showMessageDialog(null, "Now give the console input ");
                int value = Integer.parseInt(JOptionPane.showInputDialog(null, "How many String do you want check"));
                for (int m = 0; m < value; m++) {
                    String transition = "";
                    //System.out.print((m+1)+". Enter the input string: ");
                    //String input = br.readLine();
                    String input = JOptionPane.showInputDialog(null, (m + 1) + ". Enter input String");
                    // BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                    //System.out.println("input String:" + input);
                    for (int i = 0; i < input.length(); i++) {
                        if (i == 0) {
                            //System.out.print((char) 65 + "-->");
                            transition += (char) 65 + "-->";
                            follow = dfa_s.get((char) 65 + "_" + input.charAt(i));
                        }
                        transition += dfa_s.get(follow + "_" + input.charAt(i)) + "-->";
                        // System.out.print(dfa_s.get(follow + "_" + input.charAt(i)) + "-->");
                        follow = dfa_s.get(follow + "_" + input.charAt(i));
                    }
                    System.out.println();
                    JOptionPane.showMessageDialog(null, transition);
                    if (resultant.contains(follow)) {
                        JOptionPane.showMessageDialog(null, "Accepted");
                    } else {
                        JOptionPane.showMessageDialog(null, "Rejected");
                        System.out.println("Rejected");
                    }
                }

                generate();
             //   System.out.println(symbol);
             //   System.out.println(states);
                System.out.println("States which are being merged to the minimization");
                JOptionPane.showMessageDialog(null, "States which are being merged to the minimization");
                for (int i = 0; i < states.size(); i++) {
                    if (!resultant.contains(states.get(i))) {
                        for (int j = i + 1; j < states.size(); j++) {
                            if (!resultant.contains(states.get(j))) {

                                //System.out.println(states.get(i)+" "+states.get(j));
                                LinkedList<String> bl = new LinkedList<String>();
                                for (int k = 0; k < in_symbol.size(); k++) {
                                    // System.out.println(in_symbol.get(k)+" "+k);
                                    if (checker(in_symbol.get(k), states.get(i), states.get(j))) {
                                        bl.add("true");
                                    } else {
                                        bl.add("false");
                                    }
                                }
                                // System.out.println(bl);
                                if (!bl.contains("false") == true) {
                                    if (min_states.isEmpty() || !min_states.containsKey(states.get(i))) {
                                        min_states.put(states.get(i), states.get(i) + "_" + states.get(j));
                                    }
                                    if (min_states.containsKey(states.get(i))) {
                                        boolean do_input = false;
                                        StringTokenizer st = new StringTokenizer(min_states.get(states.get(i)));
                                        while (st.hasMoreElements()) {
                                            String update = st.nextToken("_");
                                            System.out.println(update);
                                            if (update.equals(states.get(j))) {
                                                do_input = true;
                                            }
                                        }
                                        if (do_input == false) {
                                            String update = min_states.get(states.get(i)) + "_" + states.get(j);
                                            min_states.put(states.get(i), update);
                                        }
                                    }
                                    System.out.println("we will merge them");
                                }
                                bl.clear();
                            }

                        }
                    }

                }
                JOptionPane.showMessageDialog(null, "merged states are \n"+min_states );
                System.out.println("The merged states are");
                System.out.println(min_states);
                LinkedList<String> z = new LinkedList<String>();

                for (int j = 0; j < states.size() - 1; j++) {
                    for (int i = 0; i < states.size(); i++) {
                        String bondage = "";
                        if (min_states.containsKey(states.get(i))) {

                            if (z.size() == 0) {
                                String tap = min_states.get(states.get(i));
                                StringTokenizer st = new StringTokenizer(tap);
                                while (st.hasMoreElements()) {
                                    String chip = st.nextToken("_");
                                    System.out.println("this is " + states.get(i) + "     " + chip);
                                    bondage += chip + "_";
                                    if (min_states.containsKey(chip)) {
                                        z.add(chip);
                                        System.out.println("and the z value is " + z);
                                        bondage += chip.replaceAll(chip, min_states.get(chip)) + "_";
                                    }
                                }
                                new_states.put(states.get(i), bondage);
                            }
                            if (!z.contains(states.get(i))) {
                                String tap = min_states.get(states.get(i));
                                StringTokenizer st = new StringTokenizer(tap);
                                while (st.hasMoreElements()) {
                                    String chip = st.nextToken("_");
                                    bondage += chip + "_";
                                    if (min_states.containsKey(chip)) {
                                        z.add(chip);
                                        bondage += chip.replaceAll(chip, min_states.get(chip)) + "_";
                                    }
                                }
                                new_states.put(states.get(i), bondage);
                            }
                        }



                    }
                }
                System.out.println(new_states);
                LinkedList<String> store = new LinkedList<String>();
                for (int i = 0; i < states.size(); i++) {
                    String update = "";
                    if (new_states.containsKey(states.get(i)) && !store.contains(states.get(i))) {
                        StringTokenizer st = new StringTokenizer(new_states.get(states.get(i)));
                        while (st.hasMoreElements()) {
                            String put = st.nextToken("_");
                            if (!store.contains(put)) {
                                update = update + "_" + put;
                                store.add(put);
                            }
                        }
                    }
                    merged_states.put(states.get(i), update);
                }
                LinkedHashMap<String, String> final_states = new LinkedHashMap<String, String>();
                for (int i = 0; i < states.size(); i++) {
                    if (!final_states.containsKey(states.get(i))) {
                        String bond = merged_states.get(states.get(i));
                        if (bond.equals("")) {
                            final_states.put(states.get(i), states.get(i));
                        } else {
                            String rand = merged_states.get(states.get(i));
                            StringTokenizer st = new StringTokenizer(rand);
                            while (st.hasMoreElements()) {
                                final_states.put(st.nextToken("_"), rand);
                            }
                        }
                    }
                }
                for (int i = 0; i < resultant.size(); i++) {
                    String r = "";
                    for (int j = 0; j < resultant.size(); j++) {
                        r += "_" + resultant.get(j);
                    }
                    final_states.put(resultant.get(i), r);
                }
                System.out.println(final_states);
                for (int i = 0; i < dfa_s.size() / edges; i++) {
                    for (int j = 0; j < edges; j++) {
                       // System.out.print(dfa_s.get(states.get(i) + "_" + (char) (j + in_symbol.getFirst().charAt(0))));
                        String keep = final_states.get(dfa_s.get(states.get(i) + "_" + (char) (j + in_symbol.getFirst().charAt(0))));
                        min_dfa.put(final_states.get(states.get(i)) + "_" + (char) (j + in_symbol.getFirst().charAt(0)), keep);
                     //  String repeat=final_states.get(states.get(i)) + "_" + (char) (j + in_symbol.getFirst().charAt(0));
                    }
                    String repeat=final_states.get(states.get(i));
                    StringTokenizer sp=new StringTokenizer(repeat);
                    while(sp.hasMoreElements()){
                        if(resultant.contains(sp.nextToken("_"))){
                            min_resultant.add(repeat);
                        }
                        else
                        break;
                    }
                    System.out.println();
                }

                JOptionPane.showMessageDialog(null, "This is the minimized dfa HashMap small letters are edges \n"+min_dfa);
                System.out.println("This is the minimized dfa where the small letters are edges and block are merged states ");
                System.out.println(min_dfa);
                System.out.println(final_states);
                System.out.println("this is the final state of minimized dfa :");
                JOptionPane.showMessageDialog(null, "The final state of minimized dfa is \n "+min_resultant);
                System.out.println(min_resultant);
                JOptionPane.showMessageDialog(null, "sorry for your patience sorry my code is toooo naive & tooooo long\n"
                        + "please dont be angry. \n Thank you for co-operation");

                break;
            }
            case 2:

                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

                nfa.put("0_a", "");
                nfa.put("0_b", "");
                nfa.put("0_e", "1_7");

                nfa.put("1_a", "");
                nfa.put("1_b", "");
                nfa.put("1_e", "4_2");

                nfa.put("2_a", "3");
                nfa.put("2_b", "");
                nfa.put("2_e", "");

                nfa.put("3_a", "");
                nfa.put("3_b", "");
                nfa.put("3_e", "6");

                nfa.put("4_a", "");
                nfa.put("4_b", "5");
                nfa.put("4_e", "");

                nfa.put("5_a", "");
                nfa.put("5_b", "");
                nfa.put("5_e", "6");

                nfa.put("6_a", "");
                nfa.put("6_b", "");
                nfa.put("6_e", "1_7");

                nfa.put("7_a", "8");
                nfa.put("7_b", "");
                nfa.put("7_e", "");

                nfa.put("8_a", "");
                nfa.put("8_b", "9");
                nfa.put("8_e", "");

                nfa.put("9_a", "");
                nfa.put("9_b", "10");
                nfa.put("9_e", "");

                nfa.put("10_a", "");
                nfa.put("10_b", "");
                nfa.put("10_e", "");

                System.out.println(in_symbol);
                System.out.println(first);
                System.out.println(last);
                System.out.print(nfa);
                in_symbol.add("a");
                in_symbol.add("b");
                result.add(10);

                eclosebuilder();
                symbol.put(eget.get(first + ""), (char) sym + "");
                states.add((char) sym + "");
                sym++;
                final_states(eget.get(first + ""));
                System.out.println("this is first input " + symbol);
                ecloser(first + "");
                //System.out.println(eget);z

                while (!rad.isEmpty()) {
                    rat.clear();
                    String set = rad.getFirst();
                    //System.out.println("this is set "+set);
                    rad.removeFirst();
                    StringTokenizer st = new StringTokenizer(set);
                    while (st.hasMoreElements()) {
                        String risk = st.nextToken("_");
                        efusser(risk);
                    }
                    for (int r = a; r <= c; r++) {
                        dfbuilder(set, rat.get((char) r + "_"), r);
                    }
                }

                System.out.println(" Final dfa ");
                System.out.println(dfa);
                JOptionPane.showMessageDialog(null, "This is my dfa HashMap small letters are edges"
                        + "\n & numbers  are states "+"\n"+dfa);
                System.out.println("Value considering as symbols");
                System.out.println(symbol);
                JOptionPane.showMessageDialog(null, "the value which are accepting as Symbols \n"+symbol);
                System.out.println("Final symbolic dfa");
                System.out.println(dfa_s);
                JOptionPane.showMessageDialog(null, "This is my main dfa HashMap small letters are"
                        + " edges & Block letters are State \n"+dfa_s);
                System.out.println("Final States are :");
                System.out.println(resultant);
                JOptionPane.showMessageDialog(null, "Final States are \n"+resultant);

                JOptionPane.showMessageDialog(null, "Now give the console input ");
                int value = Integer.parseInt(JOptionPane.showInputDialog(null, "How many String do you want check"));
                for (int m = 0; m < value; m++) {
                    String transition = "";
                    //System.out.print((m+1)+". Enter the input string: ");
                    //String input = br.readLine();
                    String input = JOptionPane.showInputDialog(null, (m + 1) + ". Enter input String");
                    // BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                    //System.out.println("input String:" + input);
                    for (int i = 0; i < input.length(); i++) {
                        if (i == 0) {
                            //System.out.print((char) 65 + "-->");
                            transition += (char) 65 + "-->";
                            follow = dfa_s.get((char) 65 + "_" + input.charAt(i));
                        }
                        transition += dfa_s.get(follow + "_" + input.charAt(i)) + "-->";
                        // System.out.print(dfa_s.get(follow + "_" + input.charAt(i)) + "-->");
                        follow = dfa_s.get(follow + "_" + input.charAt(i));
                    }
                    System.out.println();
                    JOptionPane.showMessageDialog(null, transition);
                    if (resultant.contains(follow)) {
                        JOptionPane.showMessageDialog(null, "Accepted");
                    } else {
                        JOptionPane.showMessageDialog(null, "Rejected");
                        System.out.println("Rejected");
                    }
                }



                generate();
             //   System.out.println(symbol);
             //   System.out.println(states);
                System.out.println("States which are being merged to the minimization");
                JOptionPane.showMessageDialog(null, "States which are being merged to the minimization");
                for (int i = 0; i < states.size(); i++) {
                    if (!resultant.contains(states.get(i))) {
                        for (int j = i + 1; j < states.size(); j++) {
                            if (!resultant.contains(states.get(j))) {

                                //System.out.println(states.get(i)+" "+states.get(j));
                                LinkedList<String> bl = new LinkedList<String>();
                                for (int k = 0; k < in_symbol.size(); k++) {
                                    // System.out.println(in_symbol.get(k)+" "+k);
                                    if (checker(in_symbol.get(k), states.get(i), states.get(j))) {
                                        bl.add("true");
                                    } else {
                                        bl.add("false");
                                    }
                                }
                                // System.out.println(bl);
                                if (!bl.contains("false") == true) {
                                    if (min_states.isEmpty() || !min_states.containsKey(states.get(i))) {
                                        min_states.put(states.get(i), states.get(i) + "_" + states.get(j));
                                    }
                                    if (min_states.containsKey(states.get(i))) {
                                        boolean do_input = false;
                                        StringTokenizer st = new StringTokenizer(min_states.get(states.get(i)));
                                        while (st.hasMoreElements()) {
                                            String update = st.nextToken("_");
                                            System.out.println(update);
                                            if (update.equals(states.get(j))) {
                                                do_input = true;
                                            }
                                        }
                                        if (do_input == false) {
                                            String update = min_states.get(states.get(i)) + "_" + states.get(j);
                                            min_states.put(states.get(i), update);
                                        }
                                    }
                                    System.out.println("we will merge them");
                                }
                                bl.clear();
                            }

                        }
                    }

                }
                JOptionPane.showMessageDialog(null, "merged states are \n"+min_states );
                System.out.println("The merged states are");
                System.out.println(min_states);
                LinkedList<String> z = new LinkedList<String>();

                for (int j = 0; j < states.size() - 1; j++) {
                    for (int i = 0; i < states.size(); i++) {
                        String bondage = "";
                        if (min_states.containsKey(states.get(i))) {

                            if (z.size() == 0) {
                                String tap = min_states.get(states.get(i));
                                StringTokenizer st = new StringTokenizer(tap);
                                while (st.hasMoreElements()) {
                                    String chip = st.nextToken("_");
                                    System.out.println("this is " + states.get(i) + "     " + chip);
                                    bondage += chip + "_";
                                    if (min_states.containsKey(chip)) {
                                        z.add(chip);
                                        System.out.println("and the z value is " + z);
                                        bondage += chip.replaceAll(chip, min_states.get(chip)) + "_";
                                    }
                                }
                                new_states.put(states.get(i), bondage);
                            }
                            if (!z.contains(states.get(i))) {
                                String tap = min_states.get(states.get(i));
                                StringTokenizer st = new StringTokenizer(tap);
                                while (st.hasMoreElements()) {
                                    String chip = st.nextToken("_");
                                    bondage += chip + "_";
                                    if (min_states.containsKey(chip)) {
                                        z.add(chip);
                                        bondage += chip.replaceAll(chip, min_states.get(chip)) + "_";
                                    }
                                }
                                new_states.put(states.get(i), bondage);
                            }
                        }



                    }
                }
                System.out.println(new_states);
                LinkedList<String> store = new LinkedList<String>();
                for (int i = 0; i < states.size(); i++) {
                    String update = "";
                    if (new_states.containsKey(states.get(i)) && !store.contains(states.get(i))) {
                        StringTokenizer st = new StringTokenizer(new_states.get(states.get(i)));
                        while (st.hasMoreElements()) {
                            String put = st.nextToken("_");
                            if (!store.contains(put)) {
                                update = update + "_" + put;
                                store.add(put);
                            }
                        }
                    }
                    merged_states.put(states.get(i), update);
                }
                LinkedHashMap<String, String> final_states = new LinkedHashMap<String, String>();
                for (int i = 0; i < states.size(); i++) {
                    if (!final_states.containsKey(states.get(i))) {
                        String bond = merged_states.get(states.get(i));
                        if (bond.equals("")) {
                            final_states.put(states.get(i), states.get(i));
                        } else {
                            String rand = merged_states.get(states.get(i));
                            StringTokenizer st = new StringTokenizer(rand);
                            while (st.hasMoreElements()) {
                                final_states.put(st.nextToken("_"), rand);
                            }
                        }
                    }
                }
                for (int i = 0; i < resultant.size(); i++) {
                    String r = "";
                    for (int j = 0; j < resultant.size(); j++) {
                        r += "_" + resultant.get(j);
                    }
                    final_states.put(resultant.get(i), r);
                }
                System.out.println(final_states);
                for (int i = 0; i < dfa_s.size() / edges; i++) {
                    for (int j = 0; j < edges; j++) {
                       // System.out.print(dfa_s.get(states.get(i) + "_" + (char) (j + in_symbol.getFirst().charAt(0))));
                        String keep = final_states.get(dfa_s.get(states.get(i) + "_" + (char) (j + in_symbol.getFirst().charAt(0))));
                        min_dfa.put(final_states.get(states.get(i)) + "_" + (char) (j + in_symbol.getFirst().charAt(0)), keep);
                     //  String repeat=final_states.get(states.get(i)) + "_" + (char) (j + in_symbol.getFirst().charAt(0));
                    }
                    String repeat=final_states.get(states.get(i));
                    StringTokenizer sp=new StringTokenizer(repeat);
                    while(sp.hasMoreElements()){
                        if(resultant.contains(sp.nextToken("_"))){
                            min_resultant.add(repeat);
                        }
                        else
                        break;
                    }
                    System.out.println();
                }
                
                JOptionPane.showMessageDialog(null, "This is the minimized dfa HashMap small letters are edges \n"+min_dfa);
                System.out.println("This is the minimized dfa where the small letters are edges and block are merged states ");
                System.out.println(min_dfa);
                System.out.println(final_states);
                System.out.println("this is the final state of minimized dfa :");
                JOptionPane.showMessageDialog(null, "The final state of minimized dfa is \n "+min_resultant);
                System.out.println(min_resultant);
                JOptionPane.showMessageDialog(null, "sorry for your patience sorry my code is toooo naive & tooo long\n"
                        + "please dont be angry. \n Thank you for co-operation");
                break;

            default:
                System.out.println("Thank you for co-operation");
        }
    }
}
